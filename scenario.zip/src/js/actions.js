function undoChoose(context) {
    addAction({
        type: "undo_choose"
    }, context);
}
function newChoose(context){
    addAction({
        type: "newgame_choose"
    }, context);
}
function modeChoose(context){
    addAction({
        type: "mode_choose"
    }, context);
}
function colourChoose(context){
    addAction({
        type: "colour_choose"
    }, context);
}
function hintChoose(context){
    addAction({
        type: "hint_choose"
    }, context);
}
function moveChoose(note, context){
    addAction({
        type: "move_choose",
        note:note
    }, context);
}


